export { default as FontAwesomeIcon } from './components/FontAwesomeIcon'
