This project was bootstrapped with [TypeScript React Starter](https://github.com/Microsoft/TypeScript-React-Starter#typescript-react-starter).

```
yarn install
yarn start
```

NOTE: `yarn test` doesn't seem to be working right now.
